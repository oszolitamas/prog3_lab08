package lab_08;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class CaesarFrame extends JFrame {
	private JTextField inpField;
	private JTextField outField;
	private JButton button;
	private JComboBox<Object> comboBox;
	
	public CaesarFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("SwingLab");
		setSize(400, 110);
		setResizable(true);
		
		Object[] letters = new Object[26];

        for (int i = 0; i < 26; i++) {
            letters[i] = (char) ('A' + i);
        }

        comboBox = new JComboBox<>(letters);
        inpField = new JTextField(20);
        outField = new JTextField(20);
        button = new JButton("Code!");

        outField.setEditable(false);

        JPanel topPanel = new JPanel();
        topPanel.add(comboBox);
        topPanel.add(inpField);
        topPanel.add(button);

        JPanel bottomPanel = new JPanel();
        bottomPanel.add(new JLabel("Output:"));
        bottomPanel.add(outField);

        setLayout(new BorderLayout());
        add(topPanel, BorderLayout.NORTH);
        add(bottomPanel, BorderLayout.SOUTH);
        
        button.addActionListener(new OkButtonActionListener());
        
        //inpField.addKeyListener(new InputFieldKeyListener());
        
        inpField.getDocument().addDocumentListener(new InputFieldDocumentListener());
    }
	
	private String caesarCode(String input, char offset) {
		input = input.toUpperCase();
		String uj_s = "";
		for (int i = 0; i < input.length(); i++) {
			char c = input.charAt(i);
			if (c >= 'A' && c <= 'Z') {
				c = (char) ('A' + (c - 'A' + offset - 'A') % 26);
			}
			uj_s += c;
		}
		return uj_s;
	}
	
	public class OkButtonActionListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			String input = inpField.getText();
			char offset = (char) comboBox.getSelectedItem();
			String result = caesarCode(input, offset);
			outField.setText(result);
		}
	}
	
	/*
	private class InputFieldKeyListener extends KeyAdapter {
	    @Override
	    public void keyPressed(KeyEvent e) {
	        String input = inpField.getText();
	        char offset = (char) comboBox.getSelectedItem();

	        String result = caesarCode(input, offset);
	        outField.setText(result);
	    }
	}*/
	
	private class InputFieldDocumentListener implements DocumentListener {
        @Override
        public void insertUpdate(DocumentEvent e) {
            updateOutput();
        }
        @Override
        public void removeUpdate(DocumentEvent e) {
            updateOutput();
        }
        @Override
        public void changedUpdate(DocumentEvent e) {
            updateOutput();
        }
        private void updateOutput() {
            String input = inpField.getText();
            char offset = (char) comboBox.getSelectedItem();

            String result = caesarCode(input, offset);
            outField.setText(result);
        }
    }
	
	public static void main(String args[]) {
		CaesarFrame cf = new CaesarFrame();
		cf.setVisible(true);
	}
}
